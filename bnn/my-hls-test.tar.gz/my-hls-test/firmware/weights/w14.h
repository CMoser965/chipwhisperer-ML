//Numpy array shape [10, 1]
//Min -0.500672399998
//Max 0.590373337269
//Number of zeros 0

#ifndef W14_H_
#define W14_H_

#ifndef __SYNTHESIS__
model_default_t w14[10];
#else
model_default_t w14[10] = {-0.5006724000, -0.4098101854, -0.1535628438, 0.3569406867, -0.4813246727, 0.3665849566, 0.5903733373, 0.2809693217, 0.2524513006, 0.4037114978};
#endif

#endif
